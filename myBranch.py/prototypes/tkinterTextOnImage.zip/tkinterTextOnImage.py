import tkinter
from PIL import Image, ImageTk
#open a SPIDER image and convert to byte format
im = Image.open(r'SampleImage.jpg')

root = tkinter.Tk() # A root window for displaying objects

#Convert the Image object into a TkPhoto object
tkimage = ImageTk.PhotoImage(im)

#Put it in a display window
tkinter.Label(root, image=tkimage, text = "Sample Text", compound = tkinter.CENTER).pack()

root.mainloop() #Start the GUI
